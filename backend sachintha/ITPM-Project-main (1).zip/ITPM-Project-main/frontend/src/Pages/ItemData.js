// import React from 'react';
// import flower from '../Images/flower.jpg';
// import Vegitable from '../Images/Vegitable.jpg';
// import Seeds from '../Images/Seeds.jpg';


// function ItemData() {
//   return (
//     <>
//     const itemData = [
//     {
//       imag: flower,
//       title: 'Image',
//       author: 'author',
//       cols: 2,
//     },
//     {
//         img: flower,
//         title: 'Image',
//         author: 'author',
//         cols: 2,
      
//     },
//   ];
  
//   </>
//   )
// }

// export default ItemData