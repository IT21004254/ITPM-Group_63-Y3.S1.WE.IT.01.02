import React from 'react'
import ProductCatogory from '../../Components/ProductCatogory'

function Seller() {
  return (
    <>
      <ProductCatogory />

    </>
  )
}

export default Seller