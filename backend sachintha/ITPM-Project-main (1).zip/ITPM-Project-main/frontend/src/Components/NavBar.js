import React from 'react'
import Footer from './Footer'
import NavLink from './NavLink'

function NavBar() {
  return (
    <>
    <NavLink/>



    </>
  )
}

export default NavBar